{% test hub_w_source(model, column_name, model_name_t24, model_name_card, model_name_crm) %}

    {%- set model_hub_t24 = dv_config(model_name_t24) -%}
    {%- set model_hub_card = dv_config(model_name_card) -%}
    {%- set model_hub_crm = dv_config(model_name_crm) -%}
    {%- set dv_system = var("dv_system") -%}

    {%- set method = var('dv_hash_method', "sha256") -%}

    {%- if method == 'md5' -%}
        {%- set length = 32 -%}
    {%- elif method == 'sha1' -%}
        {%- set length = 40 -%}
    {%- elif method == 'sha256' -%}
        {%- set length = 64 -%}
    {%- elif method == 'sha384' -%}
        {%- set length = 96 -%}
    {%- elif method == 'sha512' -%}
        {%- set length = 128 -%}
    {%- endif -%}

    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}
    {%- set ldt_keys = ktl_autovault.render_list_dv_system_ldt_key_name(dv_system) -%}
    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}

    {%- set initial_date = get_initial_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set start_date = get_incre_start_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set end_date = get_incre_end_date_from_ref(ref('REF_T24_DATES')) -%}

    select source.{{ column_name }} as hub_redundant
    from (
        select {{ ktl_autovault.render_hash_key_hub_treatment(model_hub_t24) }}
        from 
            (select 
            distinct  {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_t24) -%}
                    {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}
            from                 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_hub_t24) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_hub_t24) }}
                {%- endif %}
            where
                1 = 1
                {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_t24) -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model.get('filter', None) -%}
                    and {{ model.get('filter') }}
                {% endif -%}
                )
        union all
        select {{ ktl_autovault.render_hash_key_hub_treatment(model_hub_card) }}
        from 
            (select 
            distinct  {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_card) -%}
                    {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}
            from                 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_hub_card) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_hub_card) }}
                {%- endif %}
            where
                1 = 1
                {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_card) -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model.get('filter', None) -%}
                    and {{ model.get('filter') }}
                {% endif -%}
                )
        union all
        select {{ ktl_autovault.render_hash_key_hub_treatment(model_hub_crm) }}
        from 
            (select 
            distinct  {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_crm) -%}
                    {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}
            from                 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_hub_crm) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_hub_crm) }}
                {%- endif %}
            where
                1 = 1
                {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_crm) -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model.get('filter', None) -%}
                    and {{ model.get('filter') }}
                {% endif -%}
                )
                ) source
    MINUS (SELECT {{ column_name }}  FROM {{ model }})
    {# source có hub không có #}
    union all 
    select {{ column_name }} as source_redundant
    from (select * 
        from {{ model}} 
        where {{ column_name}} <> cast(rpad('0', {{ length }}, '0') as raw({{ length//2 }})) 
        {# loại ghost record #}
        )
    MINUS(
    select {{ ktl_autovault.render_hash_key_hub_treatment(model_hub_t24) }}
        from 
        (
        select 
            distinct  {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_t24) -%}
                    {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}
            from                 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_hub_t24) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_hub_t24) }}
                {%- endif %}
            where
                1 = 1
                {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_t24) -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model.get('filter', None) -%}
                    and {{ model.get('filter') }}
                {% endif -%}
                )
        union all
        select {{ ktl_autovault.render_hash_key_hub_treatment(model_hub_card) }}
        from 
            (select 
            distinct  {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_card) -%}
                    {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}
            from                 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_hub_card) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_hub_card) }}
                {%- endif %}
            where
                1 = 1
                {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_card) -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model.get('filter', None) -%}
                    and {{ model.get('filter') }}
                {% endif -%}
                )
        union all
        select {{ ktl_autovault.render_hash_key_hub_treatment(model_hub_crm) }}
        from 
            (select 
            distinct  {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_crm) -%}
                    {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}
            from                 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_hub_crm) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_hub_crm) }}
                {%- endif %}
            where
                1 = 1
                {% for expr in ktl_autovault.render_list_hash_key_hub_component(model_hub_crm) -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model.get('filter', None) -%}
                    and {{ model.get('filter') }}
                {% endif -%}
                )
                )
    {# hub có source không có #}
{% endtest %}
