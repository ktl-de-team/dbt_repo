{% test lnk_w_source(model, column_name, model_name) %}

    {%- set method = var('dv_hash_method', "sha256") -%}

    {%- if method == 'md5' -%}
        {%- set length = 32 -%}
    {%- elif method == 'sha1' -%}
        {%- set length = 40 -%}
    {%- elif method == 'sha256' -%}
        {%- set length = 64 -%}
    {%- elif method == 'sha384' -%}
        {%- set length = 96 -%}
    {%- elif method == 'sha512' -%}
        {%- set length = 128 -%}
    {%- endif -%}

    {%- set model_lnk = dv_config(model_name) -%}
    {%- set dv_system = var("dv_system") -%}

    {%- set src_hkey_hub = ktl_autovault.render_list_hash_key_hub_component(model_lnk) -%}
    {%- set src_dep_keys = ktl_autovault.render_list_source_dependent_key_name(model_lnk) -%}
    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}
    {%- set ldt_keys = ktl_autovault.render_list_dv_system_ldt_key_name(dv_system) -%}

    {%- set initial_date = get_initial_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set start_date = get_incre_start_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set end_date = get_incre_end_date_from_ref(ref('REF_T24_DATES')) -%}


select * from 
(
select source. {{ column_name }}
from (
    select {{ ktl_autovault.render_hash_key_lnk_treatment(model_lnk) }}
    from 
    {% if config.get('materialized') == "streaming" -%}
        {{ ktl_autovault.render_source_view_name(model_lnk) }}
    {%- else -%}
        {{ ktl_autovault.render_source_table_name(model_lnk) }}
    {%- endif %}
    where 1=1
    {% for expr in ktl_autovault.render_list_hash_key_lnk_component(model_lnk) -%}
        and {{ expr }} is not null
    {% endfor %}
    {# biz key not null #}
    {% if start_date -%}
        {{ ldt_keys[0] }} >= {{ ktl_autovault.timestamp(start_date) }}
    {% else -%}
    {% endif -%}

    {# nếu trong dbt run có gán biến start_date thì chạy theo start_date #}

    and {{ ldt_keys[0] }} < {{ ktl_autovault.timestamp(end_date) }}  

    {# nếu trong dbt run có gán biến start_date thì chạy theo end_date #}

) source
minus 
    select  {{ column_name }}
    from {{ model }}
)
{# source xử lý thành lnk minus lnk #}
union all
select * from 
(
    select  {{ column_name }}
    from {{ model }}
    where {{ column_name }} <> cast(rpad('0', {{ length }}, '0') as raw({{ length//2 }}))
    {# loại ghost record #}
minus
select source. {{ column_name }}
from (
    select {{ ktl_autovault.render_hash_key_lnk_treatment(model_lnk) }}
    from
    {% if config.get('materialized') == "streaming" -%}
        {{ ktl_autovault.render_source_view_name(model_lnk) }}
    {%- else -%}
        {{ ktl_autovault.render_source_table_name(model_lnk) }}
    {%- endif %}
    where 1=1
    {% for expr in ktl_autovault.render_list_hash_key_lnk_component(model_lnk) -%}
        and {{ expr }} is not null
    {% endfor %}

    {% if start_date -%}
        {{ ldt_keys[0] }} >= {{ ktl_autovault.timestamp(start_date) }}
    {% else -%}
    {% endif -%}

    and {{ ldt_keys[0] }} < {{ ktl_autovault.timestamp(end_date) }}  
) source
)

{% endtest %}