{% test lsat_der_w_source(model, column_name, model_name) %}

    {%- set model_lsat_der = dv_config(model_name) -%}
    {%- set dv_system = var("dv_system") -%}

    {%- set src_hkey_lnk = ktl_autovault.render_list_hash_key_lnk_component(model_lsat_der) -%}
    {%- set src_dep_keys = ktl_autovault.render_list_source_dependent_key_name(model_lsat_der) -%}
    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}
    {%- set ldt_keys = ktl_autovault.render_list_dv_system_ldt_key_name(dv_system) -%}

    {%- set initial_date = var('initial_date', run_started_at.astimezone(modules.pytz.timezone("Asia/Ho_Chi_Minh")).strftime('%Y-%m-%d')) -%}
    {%- set start_date = var('incre_start_date', none) -%}
    {%- set end_date = var('incre_end_date', run_started_at.astimezone(modules.pytz.timezone("Asia/Ho_Chi_Minh")).strftime('%Y-%m-%d')) -%}

        select 
        {{ ktl_autovault.render_hash_key_lnk_name(model_lsat_der) }},
        {{ column_name }},
        {{ ktl_autovault.render_hash_diff_name(model_lsat_der) }}
        from (
                select 
                    {{ ktl_autovault.render_hash_key_lsat_treatment(model_lsat_der, dv_system) }},
                    {{ ktl_autovault.render_hash_key_lnk_treatment(model_lsat_der) }},
                    {{ ktl_autovault.render_hash_diff_treatment(model_lsat_der) }},
                    {% for expr in ktl_autovault.render_list_dv_system_column_treatment(dv_system) -%}
                        {{ expr }} {{- ',' if not loop.last }}
                    {% endfor %}                    
                from 
                {% if config.get('materialized') == "streaming" -%}
                    {{ ktl_autovault.render_source_view_name(model_lsat_der) }}
                {%- else -%}
                    {{ ktl_autovault.render_source_table_name(model_lsat_der) }}
                {%- endif %}
                where 
                1=1  
                {% for expr in src_hkey_lnk + src_dep_keys -%}
                    and {{ expr }} is not null
                {% endfor %}
                and {{ src_ldt_keys[0] }} >= {{ ktl_autovault.timestamp(initial_date) }}
                {% if start_date -%}
                    {{ ldt_keys[0] }} >= {{ ktl_autovault.timestamp(start_date) }}
                {% else -%}
                {% endif -%}

                and {{ ldt_keys[0] }} < {{ ktl_autovault.timestamp(end_date) }}            
            ) 
        minus
        select 
        {{ ktl_autovault.render_hash_key_lnk_name(model_lsat_der) }},
        {{ column_name }},
        {{ ktl_autovault.render_hash_diff_name(model_lsat_der) }}
        from {{ model }}

{% endtest %}