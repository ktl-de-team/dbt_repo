{% test lsat_snp_w_source(model, column_name, model_name) %}

    {%- set model_lsat_snp = dv_config(model_name) -%}
    {%- set dv_system = var("dv_system") -%}

    {%- set hkey_lnk_name = ktl_autovault.render_hash_key_lnk_name(model_lsat_snp) -%}
    {%- set src_hkey_lnk = ktl_autovault.render_list_hash_key_lnk_component(model_lsat_snp) -%}
    {%- set src_dep_keys = ktl_autovault.render_list_source_dependent_key_name(model_lsat_snp) -%}
    {%- set dep_keys = ktl_autovault.render_list_dependent_key_name(model_lsat_snp) -%} 
    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}
    {%- set ldt_keys = ktl_autovault.render_list_dv_system_ldt_key_name(dv_system) -%}
    {%- set cdc_ops = ktl_autovault.render_dv_system_cdc_ops_name(dv_system) -%}
    {%- set hash_diff = ktl_autovault.render_hash_diff_name(model_lsat_snp) -%}

    {%- set initial_date = var('initial_date', run_started_at.astimezone(modules.pytz.timezone("Asia/Ho_Chi_Minh")).strftime('%Y-%m-%d')) -%}
    {%- set start_date = var('incre_start_date', none) -%}
    {%- set end_date = var('incre_end_date', run_started_at.astimezone(modules.pytz.timezone("Asia/Ho_Chi_Minh")).strftime('%Y-%m-%d')) -%}

    select {{ column_name }},
        {{ ktl_autovault.render_hash_key_lnk_name(model_lsat_snp) }},
        {{ ktl_autovault.render_hash_diff_name(model_lsat_snp) }}
    from
    (
    select     cte.*,
                row_number() over (
                    partition by
                                {% for key in [hkey_lnk_name] + dep_keys -%}
                                    {{ key }} {{- ',' if not loop.last }}
                                {% endfor %}
                            order by
                                {% for key in ldt_keys -%}
                                    {{ key }} desc {{- ',' if not loop.last }}
                                {%- endfor %}) as row_num
    from (
    select
        {{ ktl_autovault.render_hash_key_lsat_treatment(model_lsat_snp,dv_system) }},
        {{ ktl_autovault.render_hash_key_lnk_treatment(model_lsat_snp) }},
        {{ ktl_autovault.render_hash_diff_treatment(model_lsat_snp) }},
        {% for expr in ktl_autovault.render_list_dependent_key_treatment(model_lsat_snp) -%}
            {{ expr }},
        {% endfor %}        
        {% for expr in ktl_autovault.render_list_dv_system_column_treatment(dv_system) -%}
            {{ expr }} {{- ',' if not loop.last }}
        {% endfor %}
    from 
        {% if config.get('materialized') == "streaming" -%}
            {{ ktl_autovault.render_source_view_name(model_lsat_snp) }}
        {%- else -%}
            {{ ktl_autovault.render_source_table_name(model_lsat_snp) }}
        {%- endif %}
    where 1=1
        {% for expr in src_hkey_lnk + src_dep_keys -%}
            and {{ expr }} is not null
        {% endfor %}

        {% if start_date -%}
            {{ ldt_keys[0] }} >= {{ ktl_autovault.timestamp(start_date) }}
        {% else -%}
        {% endif -%}

        and {{ ldt_keys[0] }} < {{ ktl_autovault.timestamp(end_date) }}            
    )cte
    )
    where row_num =1 
    minus
    select {{ column_name }},
        {{ ktl_autovault.render_hash_key_lnk_name(model_lsat_snp) }},
        {{ ktl_autovault.render_hash_diff_name(model_lsat_snp) }}
    from {{ model }}

{% endtest %}