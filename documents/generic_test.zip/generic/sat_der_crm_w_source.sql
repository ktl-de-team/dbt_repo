{% test sat_der_crm_w_source(model, column_name, model_name) %}

    {%- set model_sat_der = dv_config(model_name) -%}
    {%- set dv_system = var("dv_system") -%}
    {%- set method = var('dv_hash_method', "sha256") -%}
    {%- if method == 'md5' -%}
        {%- set length = 32 -%}
    {%- elif method == 'sha1' -%}
        {%- set length = 40 -%}
    {%- elif method == 'sha256' -%}
        {%- set length = 64 -%}
    {%- elif method == 'sha384' -%}
        {%- set length = 96 -%}
    {%- elif method == 'sha512' -%}
        {%- set length = 128 -%}
    {%- endif -%}

    {%- set src_hkey_hub = ktl_autovault.render_list_hash_key_hub_component(model_sat_der) -%}
    {%- set src_dep_keys = ktl_autovault.render_list_source_dependent_key_name(model_sat_der) -%}
    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}
    {%- set ldt_keys = ktl_autovault.render_list_dv_system_ldt_key_name(dv_system) -%}
    {%- set cdc_ops = ktl_autovault.render_dv_system_cdc_ops_name(dv_system) -%}
    {%- set hash_diff = ktl_autovault.render_hash_diff_name(model_sat_der) -%}

    {%- set initial_date = get_initial_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set start_date = get_incre_start_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set end_date = get_incre_end_date_from_ref(ref('REF_T24_DATES')) -%}



        select 
        {{ column_name }}
        ,{{ ktl_autovault.render_hash_diff_name(model_sat_der) }}
        {% for name in ktl_autovault.render_list_dependent_key_name(model_sat_der) -%}
            ,{{ name }} 
        {% endfor %}
        ,{{ cdc_ops }}
        from (
                select 
                    {{ ktl_autovault.render_hash_key_sat_treatment(model_sat_der, dv_system) }},
                    {{ ktl_autovault.render_hash_key_hub_treatment(model_sat_der) }},
                    {{ ktl_autovault.render_hash_diff_treatment(model_sat_der) }} ,
                    {% for name in ktl_autovault.render_list_dependent_key_name(model_sat_der) -%}
                        {{ name }},
                    {% endfor %}
                    {% for expr in ktl_autovault.render_list_dv_system_column_treatment(dv_system) -%}
                        {{ expr }} {{- ',' if not loop.last }}
                    {% endfor %}                  
                from 
                    {{ ref( 'STG_BUT051') }}
                where 
                1=1  
                {% for expr in src_hkey_hub + src_dep_keys -%}
                    and {{ expr }} is not null
                {% endfor -%}
                
                {%- if model_sat_der.get('filter', None) -%}
                    and {{ model_sat_der.get('filter') }}
                {% endif -%}
        
                and {{ src_ldt_keys[0] }} >= {{ ktl_autovault.timestamp(initial_date) }}
        
            ) 
        minus
        select 
        {{ column_name }}
        ,{{ ktl_autovault.render_hash_diff_name(model_sat_der) }}
        {% for name in ktl_autovault.render_list_dependent_key_name(model_sat_der) -%}
            ,{{ name }} 
        {% endfor %}
        ,{{ cdc_ops }}
        from {{ model }}
        where {{ column_name}} <> cast(rpad('0', {{ length }}, '0') as raw({{ length//2 }})) 
{% endtest %}