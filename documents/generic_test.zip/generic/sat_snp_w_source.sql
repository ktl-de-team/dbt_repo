{% test sat_snp_w_source(model, column_name, model_name) %}

    {%- set model_sat = dv_config(model_name) -%}
    {%- set dv_system = var("dv_system") -%}

    {%- set src_hkey_hub = ktl_autovault.render_list_hash_key_hub_component(model_sat) -%}
    {%- set src_dep_keys = ktl_autovault.render_list_source_dependent_key_name(model_sat) -%}
    {%- set src_ldt_keys = ktl_autovault.render_list_source_ldt_key_name(dv_system) -%}
    {%- set ldt_keys = ktl_autovault.render_list_dv_system_ldt_key_name(dv_system) -%}
    {%- set dep_keys = ktl_autovault.render_list_dependent_key_name(model_sat) -%}
    {%- set hkey_hub_name = ktl_autovault.render_hash_key_hub_name(model_sat) -%}
    {%- set cdc_ops = ktl_autovault.render_dv_system_cdc_ops_name(dv_system) -%}

    {%- set initial_date = get_initial_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set start_date = get_incre_start_date_from_ref(ref('REF_T24_DATES')) -%}
    {%- set end_date = get_incre_end_date_from_ref(ref('REF_T24_DATES')) -%}


    select 
        {{ column_name }}
        ,{{ ktl_autovault.render_hash_diff_name(model_sat) }}
        {% for name in ktl_autovault.render_list_dependent_key_name(model_sat) -%}
            ,{{ name }} 
        {% endfor %}
        -- ,{{ cdc_ops }}
    from (
        select
            a.*,
            row_number() over (
                partition by {% for key in [hkey_hub_name] + dep_keys -%}
                        {{ key }} {{- ',' if not loop.last }}
                    {% endfor %}
                order by
                    {% for key in ldt_keys -%}
                        {{ key }} desc {{- ',' if not loop.last }}
                    {%- endfor %} ) as row_num
        from (
            select 
                {{ ktl_autovault.render_hash_key_sat_treatment(model_sat, dv_system) }},
                {{ ktl_autovault.render_hash_key_hub_treatment(model_sat) }},
                {{ ktl_autovault.render_hash_diff_treatment(model_sat) }},
                {% for expr in src_hkey_hub + src_dep_keys -%}
                        {{ expr }},
                {% endfor %}
                {% for expr in ktl_autovault.render_list_dv_system_column_treatment(dv_system) -%}
                        {{ expr }} {{- ',' if not loop.last }}
                {% endfor %}                    
            from 
                {{ ktl_autovault.render_source_table_name(model_sat) }}
            where 
                1=1  
                
                {% for expr in src_hkey_hub + src_dep_keys -%}
                    and {{ expr }} is not null
                {% endfor %}
                
                {%- if model_sat.get('filter', None) -%}
                    and {{ model_sat.get('filter') }}
                {% endif -%}

                and {{ src_ldt_keys[0] }} >= {{ ktl_autovault.timestamp(initial_date) }}
                {% if start_date -%}
                    and {{ src_ldt_keys[0] }} >= {{ ktl_autovault.timestamp(start_date) }}
                {% else -%}
                {% endif -%}
                {# nếu có var start_date khi dbt run thì dv_scr_ldt >= start_date #}
                and {{ src_ldt_keys[0] }} < {{ ktl_autovault.timestamp(end_date) }}         
        ) a
    )
    where row_num = 1

    minus
    
    select 
        {{ column_name }}
        ,{{ ktl_autovault.render_hash_diff_name(model_sat) }}
        {% for name in ktl_autovault.render_list_dependent_key_name(model_sat) -%}
            ,{{ name }} 
        {% endfor %}
        -- ,{{ cdc_ops }}
    from {{ model }}

{% endtest %}