{% test test_CL1(model, column_name) %}

select {{ column_name }} from {{ model }} 
where  REGEXP_LIKE ( {{ column_name }}, '[ \.\,-/]') or {{ column_name }} like '% %'

{% endtest %}