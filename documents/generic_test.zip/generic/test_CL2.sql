{% test test_CL2(model, column_name, cus_code) %}

select {{ column_name }} from {{ model }} where  {{ column_name }} like '84%' or {{ column_name }} like '+84%'
union all
select {{ column_name }} from
(
with t1 as (
select {{ cus_code }}, {{ column_name }} , substr({{ column_name }} ,1,3) as len3, substr({{ column_name }} ,1,4) as len4 
from {{ model }}
)
, l3 as (
select t1.*, t2.NEW_PHONE as new3
from t1
left join( select * from mdm_phone_number_prefix where OLD_PHONE <> new_PHONE) t2
on t1. len3 = t2.old_phone
where length({{ column_name }} ) = 10
),
l4 as 
(
select t1.*, t2.NEW_PHONE new4
from t1
left join mdm_phone_number_prefix t2
on t1. len4 = t2.old_phone
where length({{ column_name }} ) = 11
)
select * from (
select l3.{{ cus_code }},l3.{{ column_name }}
,l3.len3, l4.len4
,l3.new3, l4.new4
from l3
full join l4
on l3.{{ cus_code }} = l4.{{ cus_code }}
where l3.new3 is not null or l4.new4 is not null)
)

{% endtest %}