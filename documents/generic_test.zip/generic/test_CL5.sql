{% test test_CL5(model, column_name) %}

select DATA_TYPE
from all_tab_columns 
where 
table_name = (case when '{{ model }}' like '%T24%' then 'T24_CORP_CLEANSING'
                        when '{{ model }}' like '%CARD%' then 'CARD_CORP_CLEANSING'
                        when '{{ model }}' like '%CRM%' then 'CRM_CORP_CLEANSING'
                        else '' end
                        )
and column_name = '{{ column_name }}' 
MINUS  
select 'DATE'
from DUAL


{% endtest %}