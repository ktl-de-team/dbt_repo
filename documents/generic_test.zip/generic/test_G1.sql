{% test test_G1(model, column_name, invalid_table_result ) %}

with invalid_check as (
select '{{ column_name }}' as ERROR_COLUMN, count(*) as cnt
from {{ model }}
where({{ column_name }} is null or upper ({{ column_name }}) = 'NULL'  or {{ column_name }} = '')
),
invalid_result as (
select '{{ column_name }}'  as error_column, count(*)
from {{ invalid_table_result }}
where error_code = 'G1'
and ERROR_COLUMN = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)  

{% endtest %}