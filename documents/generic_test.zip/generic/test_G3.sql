{% test test_G3(model, column_name, invalid_table_result ) %}

with invalid_check as (
select '{{ column_name }}' as ERROR_COLUMN, count(*) as cnt
from {{ model }}
where {{ column_name }} = '0' 
),
invalid_result as (
select '{{ column_name }}'  as error_column, count(*)
from {{ invalid_table_result }}
where error_code = 'G3'
and ERROR_COLUMN = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)  
  
{% endtest %}