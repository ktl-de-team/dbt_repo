{% test test_G36(model, column_name, invalid_table_result ) %}

with invalid_check as (
select '{{ column_name }}' as ERROR_COLUMN, count(*) as cnt
from {{ model }}
where  1=1
and (
REGEXP_LIKE ({{ column_name }}, '^[^A-Za-z]+$')
or REGEXP_LIKE ({{ column_name }}, '^[-.&)+:/ '''',|]')
or REGEXP_LIKE ({{ column_name }}, '[-.&(+:/ '''',|]+$'))
),
invalid_result as ( 
select '{{ column_name }}'  as error_column, count(*)
from {{ invalid_table_result }}
where error_code = 'G36'
and ERROR_COLUMN = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)  

{% endtest %}