{% test test_R43(model, column_name, invalid_table_result, cus_code) %}

  with invalid_check as (
  select {{ cus_code }}
  from (
  select {{ cus_code }}, {{ column_name }}, cate.standard_value
  from {{ model }} cl
  left join (select * from mdm_catalog_category cate where category_type = 'nghe_nghiep' and 
            source = 
                case when '{{ model }}' like '%T24%' then 'T24'
                     when '{{ model }}' like '%CARD%' then 'CARD'
                     else ''
                     end) cate
  on cl.{{ column_name }} = cate.standard_value
  where cate.standard_value is null
  and {{ column_name }} is not null
  )
), 
invalid_result as (
   select {{ cus_code }}
--    , error_value
  from {{ invalid_table_result }}
  where 1=1
  and error_code = 'R43' 
  and error_column = '{{ column_name }}'
 )
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)  
{% endtest %}