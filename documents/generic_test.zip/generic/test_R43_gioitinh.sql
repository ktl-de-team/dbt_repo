{% test test_R43_gioitinh(model, column_name, cus_code, invalid_table_result ) %}

with invalid_check as (
select {{ cus_code }} from (
select {{ cus_code }},
case 
  when {{ column_name }} in ('MALE','FEMALE') then 'valid'
  else 'invalid'
end as valid_id
from {{ model }}
where {{ column_name }}  is not null
)
where valid_id = 'invalid'
),
invalid_result as (
select {{ cus_code }} 
from {{ invalid_table_result }}
where error_column = '{{ column_name }}'
and error_code = 'R43'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)

{% endtest %}