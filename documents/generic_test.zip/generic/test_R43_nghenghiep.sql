{% test test_R43_nghenghiep(model, column_name, cus_code, invalid_table_result ) %}

with invalid_check as (
select {{ cus_code }} from (
select {{ cus_code }}, cl.{{ column_name }}, cate.standard_value
from {{ model }}   cl
left join (select * from mdm_catalog_category cate where CATEGORY_TYPE = 'nghe_nghiep' and source = (
      case 
          when '{{ model }}' like '%T24%' then 'T24'
          else 'CARD'
          end)) cate
on cl.{{ column_name }} = cate.standard_value
where cl.{{ column_name }} is not null
)
where standard_value is null
),
invalid_result as (
select {{ cus_code }}
from {{ invalid_table_result }}
where error_column = '{{ column_name }}'
and error_code = 'R43'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)

{% endtest %}