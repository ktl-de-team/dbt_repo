{% test test_R51(model, column_name, invalid_table_result ) %}

  with
  t2 as (
  select kdi01, kdi21_01, kdi22_01, kdi23_01, '{{ column_name }}',
  case when kdi15 = 'VN' or kdi15 =  'ZZ' then
          case when kdi21_01 is null and kdi22_01 is null and kdi23_01 is null then 'invalid'
          else 'valid'
          end
  else
            case when kdi23_01 is null then 'invalid'
                else 'valid' 
            end
  end as check_id             
  from {{ model }}
),
  invalid_check as (
  select kdi01
  from t2 
  where check_id = 'invalid'
),
invalid_result as (
  select kdi01
--    , error_value
  from {{ invalid_table_result }}
  where 1=1
  and error_code = 'R51' 
  and error_column = '{{ column_name }}'
  )
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)
  
{% endtest %}