{% test test_R57(model, column_name, invalid_table_result, cus_code ) %}

WITH T1 AS (
SELECT 
        {{ cus_code }}, 
        {{ column_name }},
        trim(regexp_substr(t.{{ column_name }}, '[^|]+', 1, levels.column_value)) AS EMAIL 
    FROM {{ model }} t,
    table(cast(multiset(
        select level from dual connect by  level <= length (regexp_replace(t.{{ column_name }}, '[^|]+'))  + 1
        ) as sys.OdciNumberList
        )) levels
    WHERE {{ column_name }} IS NOT NULL

),
multi_valid as (
select distinct {{ cus_code }} from (
select {{ cus_code }}
--, kdc09, mail.email
from T1 cl
left join (select * 
            from mdm_catalog_zerobound_email 
            where cus_type = 
                          (case when '{{ model }}' like '%CORP%' then 'KHDN' 
                          else 'KHCN' 
                          end
                          )
          ) mail
on lower(cl.EMAIL) = lower(mail.email)
where mail.email is not null
)
)
,
single_valid as (
select distinct {{ cus_code }} from (
select {{ cus_code }}
--, kdc09, mail.email
from T1 cl
left join (select * 
            from mdm_catalog_zerobound_email 
            where cus_type = 
                          (case when '{{ model }}' like '%CORP%' then 'KHDN' 
                          else 'KHCN' 
                          end
                          )
          ) mail
on lower(cl.EMAIL) = lower(mail.email)
where mail.email is null
minus 
select {{ cus_code }}
from {{ invalid_table_result }}
where 1=1
and error_column = '{{ column_name }}'
and error_code = 'R57'
)
)
select * from single_valid
minus 
select * from multi_valid

{% endtest %}