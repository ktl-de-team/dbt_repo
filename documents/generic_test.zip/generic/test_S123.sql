{% test test_S123(model, column_name, invalid_table_result, cus_code ) %}

with invalid_check as (
select {{ cus_code }}
from {{ model }}
where length({{ column_name }}) <4
),
invalid_result as (
select {{ cus_code }}
from {{ invalid_table_result }}
where error_code = 'S123' and error_column = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)

{% endtest %}