{% test test_S124(model, column_name, invalid_table_result, cus_code ) %}

with invalid_check as (
select {{ cus_code }} from 
(
select {{ cus_code }}, {{ column_name }}
from {{ model }}
where  {{ column_name }} is not null
minus
select {{ cus_code }},  {{ column_name }}
from {{ model }}
where
regexp_like({{ column_name }},'^[0 00 +]([1-9]{1}|[0-9])' )
)
)
, invalid_result as ( 
select {{ cus_code }}
from {{ invalid_table_result }}
where error_code = 'S124' and error_column = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)
  
{% endtest %}