{% test test_S229(model, column_name, invalid_table_result, cus_code ) %}

with t1 as (
select {{ cus_code }}, {{ column_name }}, substr({{ column_name }},1, instr({{ column_name }}, '@') -1) as head,
substr({{ column_name }},instr({{ column_name }}, '@') +1, length({{ column_name }})- instr({{ column_name }}, '@')) as tail
from {{ model }}
--where upper(kdc09) = 'ABC@SACOMBANK.COM'
),
invalid_check as (
select {{ cus_code }} from (
select t1.{{ cus_code }}
from t1 
join (select * from mdm_catalog_prefix_email where cus_type = 
		case when '{{ model }}'  like '%CORP%' then 'KHDN'
		     else 'KHCN'  end) head_prefix
on upper(t1.head) = upper(head_prefix.PRE_EMAIL)
union 
select t1.{{ cus_code }}
from t1 
join (select * from mdm_catalog_suffix_email where cus_type = 
		case when '{{ model }}'  like '%CORP%' then 'KHDN'
		     else 'KHCN'  end )tail_prefix
on upper(t1.tail) = upper(tail_prefix.SUFFIX_EMAIL)
)
),
invalid_result as (
select {{ cus_code }}
from {{ invalid_table_result }}
where 1=1
and error_code = 'S229' 
and error_column = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check
  )
{% endtest %}

