{% test test_S261(model, column_name, invalid_table_result, cus_code ) %}

with  invalid_check as (
  select {{ cus_code }} from {{ model }} where {{ column_name }} = to_date('1900-01-01', 'yyyy-MM-dd')
  ),
invalid_result as (  
  select {{ cus_code }}
--    , error_value
  from {{ invalid_table_result }}
  where 1=1
  and error_code = 'S261' 
  and error_column = '{{ column_name }}'
 )   
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check
  )
{% endtest %}