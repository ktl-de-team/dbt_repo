{% test test_S267(model, column_name, invalid_table_result, id_column, cus_code ) %}
    
with t1 as (
    SELECT 
        {{ cus_code }}, 
        KDI07,
        {{ column_name }},
        {{ column_name }} AS date_id 
    FROM {{ model }} t
    WHERE {{ id_column }} IS NOT NULL
),
t2 as (
select {{ cus_code }}, {{ column_name }}, date_id, kdi07,
case when kdi07 is not null then
        case when (sysdate - kdi07)/365 <= 50 then
            case when (sysdate - (date_id)) / 365 <= 15  then 'valid'
                  else 'invalid'
            end
        else 'valid' end
else 'invalid' end as check_id             
from t1
),
invalid_check as (
select {{cus_code }}
from t2
where check_id = 'invalid'
),
invalid_result as (
 select {{ cus_code }}
--    , error_value
from {{ invalid_table_result }}
where 1=1
and error_code = 'S267' 
and error_column = '{{ column_name }}'
)
 select * from (
  select * from invalid_check minus select * from invalid_result)
  union all
 select * from (
  select * from invalid_result minus select * from invalid_check
  )

{% endtest %}