{% test test_S35(model, column_name, invalid_table_result, id_column, cus_code ) %}

  with t1 as (
    SELECT 
        {{ cus_code }}, 
        KDI07,
        {{ id_column }},
        {{ column_name }}
    FROM {{ model }} t
    WHERE {{ id_column }} IS NOT NULL
  ),
  t2 as (
  select {{ cus_code }}, {{ column_name }}, kdi07,
  case when {{ id_column }} is not null then
    case when kdi07 is not null then
            case when {{ column_name }} is null then 'invalid'
                 when {{ column_name }} >= kdi07 and {{ column_name }} <= trunc(sysdate) then 'valid'
                 else 'invalid'
            end
          when kdi07 is null then
                case when {{ column_name }} <= trunc(sysdate)  then 'valid'
                     else 'invalid' 
                end
                else 'invalid'
    end
    when {{ id_column }} is null and {{ column_name }} is null then 'valid'
    else  'invalid'
  end as check_id             
  from t1
  ),
  invalid_check as (
  select {{ cus_code }} 
  from t2 
  where check_id = 'invalid'
  ),
  invalid_result as (
  select {{ cus_code }}
--    , error_value
  from {{ invalid_table_result }}
  where 1=1
  and error_code = 'S35' 
  and error_column = '{{ column_name }}'
  )
  select * from (
  select * from invalid_check minus select * from invalid_result)
  union all
  select * from (
  select * from invalid_result minus select * from invalid_check
  )
    
{% endtest %}