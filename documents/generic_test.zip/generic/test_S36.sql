{% test test_S36(model, column_name, invalid_table_result, cus_code ) %}

with cast_to_multirow as (
    SELECT 
        {{ cus_code }}, 
        {{ column_name }},
        trim(regexp_substr(t.{{ column_name }}, '[^|]+', 1, levels.column_value)) AS EMAIL 
    FROM {{ model }} t,
    table(cast(multiset(
        select level from dual connect by  level <= length (regexp_replace(t.{{ column_name }}, '[^|]+'))  + 1
        ) as sys.OdciNumberList
        )) levels
    WHERE {{ column_name }} IS NOT NULL
)
,invalid_email as (
    select {{ cus_code }}, {{ column_name }}
    from cast_to_multirow 
    where  {{ column_name }} is not null
    minus
    select {{ cus_code }},  {{ column_name }}
    from cast_to_multirow 
    where 1=1
    and regexp_like ( {{ column_name }}, '^[a-zA-Z0-9]*[a-zA-Z0-9.''\`\%\&\_\-]+@[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,4}$')
),
invalid_result as (
select {{ cus_code }}, error_value
from {{ invalid_table_result }}
where 1=1
and error_code = 'S36' 
and error_column = '{{ column_name }}'
)
select * from (
select * from  invalid_email minus select * from invalid_result )
union all
select * from (
select * from invalid_result minus select * from  invalid_email )

{% endtest %}

