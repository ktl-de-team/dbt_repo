{% test test_V10(core_source, model, column_name, invalid_table_result, sex, dob ) %}
   WITH t1 as(
        SELECT kdi01, {{ sex }}, {{ dob }}, {{ column_name }}
        ,CASE WHEN ({{ dob }} IS NULL OR {{ sex }} IS NULL OR {{ column_name }} IS NULL) THEN 'True'
        		WHEN {{ dob }} IS NOT NULL THEN 
        		CASE WHEN EXTRACT( YEAR FROM {{ dob }} ) >= 1900 AND EXTRACT( YEAR FROM {{ dob }} ) <=1999 THEN 
	                CASE WHEN gender.gender_code = 0 THEN '0'
	                    WHEN gender.gender_code = 1 THEN '1'
	                    ELSE 'False' END
                WHEN EXTRACT( YEAR FROM {{ dob }} ) > 1999  THEN 
	                CASE WHEN gender.gender_code = 0 THEN '2'
	                    WHEN gender.gender_code = 1 THEN '3'
	                    ELSE 'False' END
                ELSE 'False' END 
                END AS sexnbirth
        ,substr({{ column_name }}, 4,1) socccd
        FROM {{ model }} cc 
        LEFT JOIN (select * 
                    from LAKEHOUSE.mdm_catalog_source_gender  
                    where source =
                    case when LOWER ('{{ core_source }}') = 'corebank' then 'CoreBank'
                         when LOWER ('{{ core_source }}') = 'corecard' then 'CoreCard'
                         when LOWER ('{{ core_source }}') = 'los' then 'Los'
                         else ''
                         end
                    ) gender  
        ON cc.{{ sex }} = GENDER. gender_value
        )
        ,valid AS 
        {# temp table 1: table valid: chứa 1 trong 3 cột giới tính, ngày sinh, cccd null 
        hoặc thỏa điều kiện rule: số cccd phù hợp giới tính #}
        (SELECT *
        FROM t1 
        WHERE sexnbirth = 'True' 
        	OR sexnbirth = socccd)
        , invalid AS 
        {# temp table 2: table invalid: chứa 3 cột giới tính, ngày sinh, cccd đều not null 
        nhưng có số cccd không phù hợp giới tính #}
        (SELECT 
        * FROM t1
        WHERE sexnbirth <>  'True'
        	AND sexnbirth <> socccd)
        {# lấy temp_invalid nhưng không có trong bảng invalid V10
        union 
        temp_valid nhưng có trong invaid V10 #}
        SELECT * FROM invalid
        WHERE kdi01 NOT IN (SELECT kdi01 FROM {{ invalid_table_result }} ci WHERE error_code = 'V10')
        UNION ALL
        SELECT * FROM valid
        WHERE kdi01 IN (SELECT kdi01 FROM {{ invalid_table_result }} ci WHERE error_code = 'V10')
{% endtest %}