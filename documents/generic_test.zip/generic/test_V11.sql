{% test test_V11(core_source, model, column_name, invalid_table_result, sex ) %}
    WITH t1 as(
        SELECT kdi01,{{ column_name }}, {{ sex }}, g.gender_value,
        CASE WHEN g.GENDER_CODE = 0 THEN 'Mr' 
            WHEN g.GENDER_CODE = 1 THEN 'Mrs'
            ELSE 'False'
            END AS danhxung
        FROM {{ model }} cc
        LEFT JOIN (SELECT * FROM LAKEHOUSE.mdm_catalog_source_gender 
                    where source =
                    case when LOWER ('{{ core_source }}') = 'corebank' then 'CoreBank'
                         when LOWER ('{{ core_source }}') = 'corecard' then 'CoreCard'
                         when LOWER ('{{ core_source }}') = 'los' then 'Los'
                         else ''
                    end) g
        ON cc.{{ sex }} = g.GENDER_VALUE
    )
    , valid AS (
        SELECT * FROM t1 
        WHERE {{ column_name }} IS NULL 
        OR {{ sex }} IS NULL
        OR danhxung = {{ column_name }}
    )
    , invalid AS (
        SELECT * FROM t1 
        WHERE {{ column_name }} IS NOT NULL AND {{ sex }} IS NOT NULL 
        AND danhxung <> {{ column_name }}
    )
    SELECT * FROM valid 
    WHERE kdi01 IN (
            SELECT kdi01 
            FROM {{ invalid_table_result }} ci 
            WHERE error_code = 'V11')
    UNION ALL 
    SELECT * FROM invalid 
    WHERE kdi01 not IN (
            SELECT kdi01 
            FROM {{ invalid_table_result }} ci 
            WHERE error_code = 'V11')
{% endtest %}