{% test test_V18( model, column_name, invalid_table_result) %}
WITH t1 as(
    SELECT kdi01, {{ column_name }}, SUBSTR({{ column_name }},1,3)  AS sodt
    FROM {{ model }} cc2
    WHERE {{ column_name }} IS NOT null)
SELECT t1.*,phone.*
    FROM t1  
    LEFT JOIN LAKEHOUSE.mdm_phone_number_prefix phone
    ON t1.sodt = phone.NEW_PHONE 	
WHERE phone.NEW_PHONE IS NULL
    AND kdi01 not IN 
        (SELECT kdi01 FROM {{ invalid_table_result }} ci WHERE error_code = 'V18')
union all 
SELECT t1.*,phone.*
    FROM t1  
    LEFT JOIN LAKEHOUSE.mdm_phone_number_prefix phone
    ON t1.sodt = phone.NEW_PHONE 	
WHERE phone.NEW_PHONE IS not NULL
    and kdi01 in 
        (SELECT kdi01 FROM {{ invalid_table_result }} ci WHERE error_code = 'V18')
{% endtest %}