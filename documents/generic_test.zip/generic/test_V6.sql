{% test test_V6(model, column_name, invalid_table_result, cus_code ) %}


    SELECT *
        FROM {{ model }} cc  
        WHERE
        (ascii(SUBSTR({{ column_name }} , 1,1)) between ascii('A') and ascii('Z')
        or ascii(SUBSTR({{ column_name }}  , 1,1)) between ascii('a') and ascii('z'))
        AND LENGTH({{ column_name }} ) >=7 
        and LENGTH({{ column_name }} ) <= 9
        AND {{ column_name }}  IS not NULL
        AND {{ cus_code }} IN 
        (SELECT {{ cus_code }}  FROM {{ invalid_table_result }} ci WHERE error_code = 'V6' and error_column = '{{ column_name }}' )
        
    union all 

    SELECT *
        FROM {{ model }} cc  
        WHERE
        {{ cus_code }} NOT in 
            (SELECT {{ cus_code }}  FROM {{ invalid_table_result }} ci WHERE error_code = 'V6' and error_column = '{{ column_name }}')
        AND (
            LENGTH( {{ column_name }} ) <7 
            or LENGTH( {{ column_name }} ) > 9
            OR (
                (ascii(SUBSTR({{ column_name }} , 1,1)) not between ascii('A') and ascii('Z')
                and ascii(SUBSTR({{ column_name }} , 1,1)) not between ascii('a') and ascii('z'))
                )
            )
        AND {{ column_name }} IS not NULL

{% endtest %}