{% test test_V7(model, column_name, invalid_table_result, cus_code ) %}

with invalid_check as (
select {{ cus_code }}, {{ column_name }}
from {{ model }}  where regexp_like({{ column_name }}, '[^0-9]{12}')
),
invalid_result as (
select {{ cus_code }}, error_value
from {{ invalid_table_result }}
where error_code = 'V7'
and error_column = '{{ column_name }}'
)
select * from (
select * from invalid_check minus select * from invalid_result)
union all
select * from (
select * from invalid_result minus select * from invalid_check
)

{% endtest %}