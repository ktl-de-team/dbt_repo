{% test test_V8(model, column_name, invalid_table_result, dob, cus_code ) %}
    WITH t1 as(
        SELECT {{ cus_code }}
        ,{{ dob }}
        ,substr(TO_CHAR(EXTRACT (YEAR from {{ dob }} )),3) AS nsinh
        ,{{ column_name}}
        , substr({{ column_name }},5,2) cccd
        FROM {{ model }} cc 
        where {{ column_name }} is not null
        )
    ,invalid_check as (
    SELECT {{ cus_code }} FROM t1 
    WHERE nsinh <> cccd 
    )
    ,invalid_result as 
    (
        SELECT {{ cus_code }}
        FROM {{ invalid_table_result }}  ci
        WHERE error_code = 'V8'
        AND error_column = '{{ column_name }}' )
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)     
        
{% endtest %}