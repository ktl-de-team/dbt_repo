{% test test_V9(model, column_name, invalid_table_result, cus_code) %}
WITH t1 AS (
    SELECT {{ cus_code }}  , SUBSTR({{ column_name }}, 1, 3) AS matinh
    FROM {{ model }} cc 
    WHERE {{ column_name }} IS NOT null
    )
,invalid_check as (
    SELECT t1.{{ cus_code }}
    FROM t1
    LEFT JOIN mdm_catalog_province_code t2
    ON t1.matinh = t2. province_code
    WHERE t2.PROVINCE_CODE IS NULL
),
invalid_result as (
SELECT {{ cus_code }}
    FROM {{ invalid_table_result }} 
        WHERE error_code = 'V9' and error_column = '{{ column_name }}'
)
select * from (
  select * from invalid_check minus select * from invalid_result)
union all
select * from (
  select * from invalid_result minus select * from invalid_check)

{% endtest %}