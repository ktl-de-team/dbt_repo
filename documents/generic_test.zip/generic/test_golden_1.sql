create table fake_golden_1  as (
select * from (
with prior1 as (
select t24.kdi01 as kdi01_t24, card.kdi01 as kdi01_card, t24.kdi02 as t24_kdi02, card.kdi02 card_kdi02, t24.KDI02_ERR_CNT as t24_cnt, card.KDI02_ERR_CNT as card_cnt,
case
    when t24.KDI02_ERR_CNT = 0 then t24.kdi02
    else
        case
            when card.KDI02_ERR_CNT = 0 then card.kdi02
            else t24.kdi02
        end
    end as golden_kdi02
from (select * from t24_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) t24
join (select * from card_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) card
on t24.kdi22_01 = card.kdi22_01
)
, prior2 as (
select t24.kdi01 as kdi01_t24, card.kdi01 as kdi01_card, t24.kdi02 as t24_kdi02, card.kdi02 card_kdi02, t24.KDI02_ERR_CNT as t24_cnt, card.KDI02_ERR_CNT as card_cnt,
case
    when t24.KDI02_ERR_CNT = 0 then t24.kdi02
    else
        case
            when card.KDI02_ERR_CNT = 0 then card.kdi02
            else t24.kdi02
        end
    end as golden_kdi02
from (select * from t24_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) t24
join (select * from card_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) card
on t24.kdi21_01 = card.kdi21_01
where not EXISTS (select 1 from prior1 where t24.kdi01 = prior1.kdi01_t24)
),
prior3 as (
select t24.kdi01 as kdi01_t24, card.kdi01 as kdi01_card, t24.kdi02 as t24_kdi02, card.kdi02 card_kdi02, t24.KDI02_ERR_CNT as t24_cnt, card.KDI02_ERR_CNT as card_cnt,
case
    when t24.KDI02_ERR_CNT = 0 then t24.kdi02
    else
        case
            when card.KDI02_ERR_CNT = 0 then card.kdi02
            else t24.kdi02
        end
    end as golden_kdi02
from (select * from t24_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) t24
join (select * from card_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) card
on t24.kdi23_01 = card.kdi23_01
where 1=1
and not EXISTS (select 1 from prior1 where t24.kdi01 = prior1.kdi01_t24)
and not EXISTS (select 1 from prior2 where t24.kdi01 = prior2.kdi01_t24)
),
prior4 as (
select t24.kdi01 as kdi01_t24, card.kdi01 as kdi01_card, t24.kdi02 as t24_kdi02, card.kdi02 card_kdi02, t24.KDI02_ERR_CNT as t24_cnt, card.KDI02_ERR_CNT as card_cnt,
case
    when t24.KDI02_ERR_CNT = 0 then t24.kdi02
    else
        case
            when card.KDI02_ERR_CNT = 0 then card.kdi02
            else t24.kdi02
        end
    end as golden_kdi02
from (select * from t24_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) t24
join (select * from card_matched where  HAS_AUTO_MATCH = 1  or HAS_DUPLICATE = 0 ) card
on t24.kdi55 = card.kdi55
and t24.kdi07 = card.kdi07
and t24.kdi02 = card.kdi02
where 1=1
and not EXISTS (select 1 from prior1 where t24.kdi01 = prior1.kdi01_t24)
and not EXISTS (select 1 from prior2 where t24.kdi01 = prior2.kdi01_t24)
and not EXISTS (select 1 from prior3 where t24.kdi01 = prior3.kdi01_t24)
)
select * from prior1
union all
select * from prior2
union all
select * from prior3
union all
select * from prior4
)
)
;