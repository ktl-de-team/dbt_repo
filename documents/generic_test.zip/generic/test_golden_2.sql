create table fake_golden_2 as (
select kdi01, kdi02
from t24_matched
where not exists (select 1 from fake_golden_1 fake where fake.kdi01_t24 = t24_matched.kdi01)
union all
select kdi01, kdi02
from card_matched
where not exists (select 1 from fake_golden_1 fake where fake.kdi01_card = card_matched.kdi01));